package org.gfg.JBDL64SpringBootDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jbdl64SpringBootDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Jbdl64SpringBootDemoApplication.class, args);
	}

}
