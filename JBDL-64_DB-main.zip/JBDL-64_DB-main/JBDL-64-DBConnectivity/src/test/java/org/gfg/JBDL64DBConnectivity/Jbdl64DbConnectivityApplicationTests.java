package org.gfg.JBDL64DBConnectivity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jbdl64DbConnectivityApplicationTests {

	@Test
	void contextLoads() {
	}

}
