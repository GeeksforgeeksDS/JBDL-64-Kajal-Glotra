package org.gfg.JBDL64DBConnectivity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jbdl64DbConnectivityApplication {

	public static void main(String[] args) {
		SpringApplication.run(Jbdl64DbConnectivityApplication.class, args);
	}

}
