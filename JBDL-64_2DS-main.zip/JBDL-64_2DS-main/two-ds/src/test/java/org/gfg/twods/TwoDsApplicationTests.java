package org.gfg.twods;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TwoDsApplicationTests {

	@Test
	void contextLoads() {
	}

}
