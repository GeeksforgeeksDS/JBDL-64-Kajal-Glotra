package org.gfg.twods;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TwoDsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TwoDsApplication.class, args);
	}

}
