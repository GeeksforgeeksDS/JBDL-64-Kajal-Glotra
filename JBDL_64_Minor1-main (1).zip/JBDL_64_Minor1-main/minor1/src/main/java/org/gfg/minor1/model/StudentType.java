package org.gfg.minor1.model;

public enum StudentType {

    ACTIVE,
    INACTIVE,
    BLOCKED;
}
