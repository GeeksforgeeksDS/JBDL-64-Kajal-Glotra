package org.gfg.minor1.model;

public enum Operator {

    EQUALS,
    LESS_THAN,
    GREATER_THAN,
    LESS_THAN_EQUALS,
    IN;
}
