package org.gfg.minor1.model;

public enum FilterType {

    BOOK_NO,

    AUTHOR_NAME,

    COST,
    BOOKTYPE;
}
