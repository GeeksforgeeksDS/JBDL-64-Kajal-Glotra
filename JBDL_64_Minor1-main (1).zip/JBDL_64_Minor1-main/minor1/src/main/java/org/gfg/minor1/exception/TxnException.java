package org.gfg.minor1.exception;

public class TxnException extends Exception{
    public TxnException(String msg){
        super(msg);
    }

}
