package org.gfg.minor1.model;

public enum TxnStatus {

    ISSUED,

    RETURNED,

    FINED;
}
