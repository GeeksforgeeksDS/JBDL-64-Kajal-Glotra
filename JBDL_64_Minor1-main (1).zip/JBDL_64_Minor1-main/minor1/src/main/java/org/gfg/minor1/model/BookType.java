package org.gfg.minor1.model;

public enum BookType {

    EDUCATIONAL,

    HISTORY,

    MOTIVATIONAL;
}
