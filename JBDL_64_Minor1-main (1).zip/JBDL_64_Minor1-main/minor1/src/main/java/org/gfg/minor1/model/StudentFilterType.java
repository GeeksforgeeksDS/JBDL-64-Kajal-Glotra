package org.gfg.minor1.model;

public enum StudentFilterType {

    CONTACT;

}
