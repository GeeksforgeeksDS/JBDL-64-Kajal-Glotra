package org.gfg.Utils;

public enum UserIdentifier {
    PAN,
    AADHAR_CARD,

    VOTER_CARD
}
