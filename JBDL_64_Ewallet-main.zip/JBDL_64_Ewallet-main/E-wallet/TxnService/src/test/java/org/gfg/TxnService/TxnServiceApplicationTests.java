package org.gfg.TxnService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TxnServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
