package org.gfg.TxnService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TxnServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TxnServiceApplication.class, args);
	}

}
