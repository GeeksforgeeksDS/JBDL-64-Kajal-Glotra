package org.gfg.TxnService.model;

public enum TxnStatus {

    PENDING,
    INITIATED,
    SUCCESS,
    FAILURE;
}
