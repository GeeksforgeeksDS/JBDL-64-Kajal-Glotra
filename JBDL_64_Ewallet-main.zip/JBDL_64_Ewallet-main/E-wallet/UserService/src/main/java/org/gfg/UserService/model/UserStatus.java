package org.gfg.UserService.model;

public enum UserStatus {
    ACTIVE,
    INACTIVE,
    BLOCKED;
}
