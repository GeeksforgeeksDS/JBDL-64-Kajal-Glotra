package org.gfg.UserService.customAnnotation;


public class UserChecks{
}
