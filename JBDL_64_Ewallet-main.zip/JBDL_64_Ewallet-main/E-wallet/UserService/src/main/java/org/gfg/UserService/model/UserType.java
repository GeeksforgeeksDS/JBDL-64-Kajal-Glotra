package org.gfg.UserService.model;

public enum UserType {

    USER,
    ADMIN,
    SERVICE;
}
