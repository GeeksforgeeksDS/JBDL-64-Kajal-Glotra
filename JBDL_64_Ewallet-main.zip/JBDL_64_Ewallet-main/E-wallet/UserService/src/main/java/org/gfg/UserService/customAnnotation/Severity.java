package org.gfg.UserService.customAnnotation;


import jakarta.validation.Payload;

public class Severity implements Payload {

}
