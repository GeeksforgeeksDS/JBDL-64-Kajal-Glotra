package abstraction;

public class InterfaceDemoClass2 implements InterfaceDemo{
    @Override
    public int getValue() {
        return 0;
    }
}

// 1 interface with multiple implemenatation
