package abstraction;

public class Client {
    public static void main(String[] args) {
//        InterfaceDemoClass interfaceDemoClass = new InterfaceDemoClass(); // 2 interfaces , we have same default method
//        System.out.println(InterfaceDemo.getStaticMathod());
//        System.out.println(interfaceDemoClass.getDefaultMathod());
//        AbstractDemo a = new AbstractDemo() {
//            @Override
//            public int getValue() {
//                return 0;
//            }
//        };
//        // anonymous class object {
////        Demo d = new Demo(){
////
////        }
//
//
//        InterfaceDemo i = new InterfaceDemo() {
//            @Override
//            public int getValue() {
//                return 0;
//            }
//        };
//        System.out.println(a.print());

//        Demo.Demo1 d1 = new Demo.Demo1();
//        d1.print1();

    }
}
