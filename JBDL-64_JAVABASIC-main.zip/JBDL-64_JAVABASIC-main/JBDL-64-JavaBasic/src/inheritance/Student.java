package inheritance;

public class Student {

    private String name;

    private int rollNo;

    private Address address; // weak, strong
}
