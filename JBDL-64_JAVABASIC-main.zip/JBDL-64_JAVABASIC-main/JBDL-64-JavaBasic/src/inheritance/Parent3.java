package inheritance;

public class Parent3 {

    int sum =30;
}
