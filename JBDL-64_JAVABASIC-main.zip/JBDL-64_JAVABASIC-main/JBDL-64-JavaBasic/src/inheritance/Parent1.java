package inheritance;

public class Parent1 {

    public int getB(){
        return 10;
    }
}
