package inheritance;

public class Address {

    public String city;

    public String pinCode;
}
