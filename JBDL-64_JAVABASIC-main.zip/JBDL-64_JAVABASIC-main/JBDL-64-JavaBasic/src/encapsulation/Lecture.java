package encapsulation;

import java.util.Date;

public class Lecture {

    private String title;

    public String mentor;

    public String getTitle() {
        return title;
    }


    public String getMentor() {
        return mentor;
    }


}

// class level variables