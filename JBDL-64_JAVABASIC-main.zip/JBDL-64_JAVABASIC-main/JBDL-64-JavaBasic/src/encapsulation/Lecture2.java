package encapsulation;

import java.util.Date;

public class Lecture2 {

    private String title;

    String mentor;

    public void setTitle(String title) {
        this.title = title;
    }

    public void setMentor(String mentor) {
        this.mentor = mentor;
    }
}
