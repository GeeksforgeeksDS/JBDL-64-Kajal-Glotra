package encapsulation.gfg;

public class Main {
}
// java project
// code will come in to src folfer

// java project
// fe code is inside ur codebase

// fe should be in react js

// be  tech but same code base


